# Bardlytics
Thunderbird community team presents: A public metrics dashboard for the Thunderbird community. It tracks activity, contributions, translations, discussions, and engagement across the ecosystem. The goal is to make our community growth and health visible, transparent, and accessible to everyone.
