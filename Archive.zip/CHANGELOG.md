# Changelog

## 0.1.1 - 2025-09-05
- Added USAGE.md and PRIVACY.md.
- Improved dashboard with About dialog, clearer labels, and friendly error states.
- Added QA_CHECKLIST.md for repeatable verification.

## 0.1.0 - 2025-09-05
- Initial MVP with GitHub ETL, seeded data, and static dashboard.

## 2025-09-05 - Added PUBLISHING.md guide
